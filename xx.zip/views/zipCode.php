<div id="zip_code" class="estimator-d-padding" style="display: none">
    <h5 class="view-title view-title-marginb k-text-center">What is your zip code?</h5>
    <p class="k-text-center k-cta subtitle view-title-marginb">In order to calculate the materials<br/> insert your zip code</p>

    <div class="k-input-field zipcode-input">
      <div class="k-field k-field-icon">
        <input type="text" class="k-input" pattern="[0-9]" id="zip-code" autocomplete="off" placeholder="Zip code" required maxlength="5" />
        <img src="../assets/img/icons/address_zipcode.svg" class="icon-input" alt="Address" />
        <label class="k-input-label">Zip code</label>
      </div>
      <p role="alert" class="k-error k-notifications zipcode-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error zip code" /> Please Enter valid Zip code</p>
    </div>

    <p class="k-cta k-text-center full-address" role="button"  tabindex="0">
      <img src="../assets/img/icons/address_zipcode.svg" class="icon-zipcode" alt="Use full address icon" /> Use full address
    </p>

    <!-- {/* Bottom */} -->
    <div class="container-estimator-2 bottom-margin70">
      <button
        id='continue-zip-code'
        type="button"
        class="k-btn-primary k-btn-large">
        Continue
      </button>
    </div>
  </div>