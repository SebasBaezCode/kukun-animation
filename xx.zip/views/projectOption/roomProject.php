<div id="estimate_options" class="estimator-d-padding">
<form action="" id="frm_estimate_kitchen">
  <!-- hidden values for project estimation -->
  <input type="hidden" id="projectTypeOrganizationId" value="<?=$projectType['projectTypeOrganizationId'];?>">
  <input type="hidden" id="projectId" value="<?=$projectObj['projectId'];?>">
  <input type="hidden" id="propertyId" value="<?=$projectObj['propertyId'];?>">
  <input type="hidden" id="userPropertyId" value="<?=$projectObj['userPropertyId'];?>">
  <input type="hidden" id="accessToken" value="<?=$projectObj['accessToken'];?>">

  <h5 class="view-title k-text-center">Estimate your <?=$projectType['projectName'];?></h5>
  <div class="k-select-field row" tabindex="0">
    <label class="k-select-label" for="renovation-type">Type of remodel</label>
    <select class="k-select " id="renovation-type">
      <option value="<?=$projectRoomConfigurations['estimationTypes'][2]['id'];?>">Renovation</option>
      <option value="<?=$projectRoomConfigurations['estimationTypes'][0]['id'];?>">Addition</option>
      <option value="<?=$projectRoomConfigurations['estimationTypes'][1]['id'];?>">Expansion</option>
    </select>
    <p role="alert" class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
  </div>

  <div class="k-select-field row addition " tabindex="0" style="display: none">
    <label class="k-select-label">Type of addition</label>
    <select class="k-select" id="additional-type">
      <?php foreach(array_reverse($projectRoomConfigurations['additionTypeDetails']) as $key => $value) {?>
        <option value="<?=$value['id'];?>"><?=ucfirst($value['name']);?></option>
      <?php }?>
    </select>
    <p role="alert" class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
  </div>
  <!--div class="k-select-field row addition" style="display: none">
    <div>
      <label class="k-select-label col s6 k-p0">Size of the addition</label>
      <div class="k-container-switch col s6 k-text-right k-p0">
        <p class="k-swtich-left">sq. ft</p>
         <input type="checkbox" class="sqft-check-addition" id="button-switch" />
         <label class="k-switch" role="button" tabindex="0">
          <span class="slider round"></span>
        </label>
        <p class="k-swtich-right">ft</p>
      </div>
    </div>
  </div-->
  <div class="k-input-field addition addition-text-box" style="display: none">
    <div class="k-field k-field-icon ">
      <input type="text" class="k-input only-number" id="size-of-addition" title="Size of the addition" autocomplete="off" placeholder="Size of the addition" required maxlength="4" />
        <!--img src="../assets/img/icons/user.svg" class="icon-input" alt="Icon" /-->
      <label class="k-input-label" for="size-of-addition">Size of the addition</label>
    </div>
    <p role="alert" class="k-error k-notifications size-of-addition-error"> 
      <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span>
    </p>
  </div>

  <div class="k-select-field row expansion" tabindex="0" style="display: none">
    <label class="k-select-label">Type of expansion</label>
    <select class="k-select" id="expansion-type">
      <?php foreach($projectRoomConfigurations['expansionTypeDetails'] as $key => $value) {?>
        <option value="<?=$value['id'];?>"><?=ucfirst($value['name']);?></option>
      <?php }?>
    </select>
    <p role="alert" class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
  </div>

  
  <div class="k-input-field expansion expansion-text-box" style="display: none">
    <div class="k-field k-field-icon ">
      <input type="text" class="k-input only-number" id="size-of-expansion" title="Size of the expansion" autocomplete="off" placeholder="Size of the expansion" required maxlength="4"/>
        <!--img src="../assets/img/icons/user.svg" class="icon-input" alt="Icon" /-->
      <label class="k-input-label" for="size-of-expansion">Size of the expansion</label>
    </div>
    <p role="alert" class="k-error k-notifications size-of-expansion-error"> 
      <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span>
    </p>
  </div>

  <div class="k-select-field row non-addition">
    <div tabindex="0">
      <label class="k-select-label col s6 k-p0">Room size</label>
      <div class="k-container-switch col s6 k-text-right k-p0">
        <p class="k-swtich-left">sq. ft</p>
        <label class="k-switch"  tabindex="0">
          <input type="checkbox" class="sqft-check" aria-label="Change size type" role="checkbox" id="button-switch" />
          <span class="slider round"></span>
        </label>
        <p class="k-swtich-right">ft</p>
      </div>
    </div>
    <div class="sqfeet">
      <select class="k-select select-size" id="project-unit">
        <?php foreach ($projectType['projectUnitDetails'] as $key => $value) {?>
          <?php $size = "(".$value['projectUnitTotalUnit']." Sq.ft)";?>
          <?php if($value['projectUnitLength'] == 0 && $value['projectUnitWidth'] == 0){
              $size = '';
              $customType = '<input type="hidden" id="customId" value="'.$value['projectUnitOrganizationId'].'">';
          }?>
          <option value="<?=$value['projectUnitOrganizationId'];?>" data-width="<?=$value['projectUnitWidth'];?>" data-length="<?=$value['projectUnitLength'];?>"><?=$value['projectUnitName'];?> <?=$size;?></option>
        <?php }?>
      </select>
      <?=$customType;?>
    </div>
    <div class="feet" style="display: none">
      <select class="k-select select-size" id="project-unit-feet">
        <?php foreach ($projectType['projectUnitDetails'] as $key => $value) {?>
          <?php $size = "(".$value['projectUnitWidth']." ft X ".$value['projectUnitLength']." ft)";?>
          <?php if($value['projectUnitLength'] == 0 && $value['projectUnitWidth'] == 0){
              $size = '';
          }?>
          <option value="<?=$value['projectUnitOrganizationId'];?>" data-width="<?=$value['projectUnitWidth'];?>" data-length="<?=$value['projectUnitLength'];?>"><?=$value['projectUnitName'];?> <?=$size;?></option>
        <?php }?>
      </select>
    </div>
  </div>
  <div class="k-input-field non-addition " >
    <div class="sqfeet-input custom-sqft-text-box" style="display: none">
      <div class="k-field k-field-icon ">
        <input type="text" class="k-input only-number" title="Custom Sq.ft size" id="custom-sqft-size" autocomplete="off" placeholder="Custom Sq.ft" required maxlength="4" />
        <!--img src="../assets/img/icons/user.svg" class="icon-input" alt="Icon" /-->
        <label class="k-input-label">Custom Sq.ft</label>
      </div>
      <p role="alert" class="k-error k-notifications custom-sqft-size-error"> 
        <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span>
      </p>
    </div>

    <div class="feet-input show-ft" style="display: none" id="container_room_size">
      <div class="div-ft-length-width d-flex" id="div_room_ft_lenght_width">
        <div class="k-input-field">
          <div class="k-field">
            <input type="text" class="k-input only-number" id="custom-length-size" aria-label="Custom length size" autocomplete="off" placeholder="Eg. 15 ft length" required maxlength="4" />
            <label class="k-input-label">Eg. 15 ft length</label>
          </div>
          <p role="alert" class="k-error k-notifications custom-length-size-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span></p>
        </div>
          <!-- //  -->
        <div class="k-input-field">
          <div class="k-field">
            <input type="text" class="k-input only-number" aria-label="Custom width size"  id="custom-width-size" autocomplete="off" placeholder="Eg. 15 ft width" required maxlength="4" />
            <label class="k-input-label">Eg. 15 ft width</label>
          </div>
          <p role="alert" class="k-error k-notifications custom-width-size-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span></p>
        </div>
      </div>
      <div class="div-ft-length-width d-flex" id="div_room_ft_lenght_width">

        <div class="k-input-field custom-length-text-box">
          <p role="alert" class="k-error k-notifications custom-length-size-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span></p>
        </div>
          <!-- //  -->
        <div class="k-input-field custom-width-text-box">
          <p role="alert" class="k-error k-notifications custom-width-size-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span></p>
        </div>


      </div>
    </div>
  </div>
  <div class="custom-feet-text-box">
    <p role="alert" class="k-error k-notifications custom-feet-size-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> <span>Error error</span></p>
  </div>

  <div class="k-select-field row" tabindex="0">
    <label class="k-select-label">Scope</label>
    <select class="k-select" id="finish-level">
      <?php foreach ($projectType['finishLevelDetails'] as $key => $value) {?>
        <option value="<?=$value['finishLevelOrganizationId'];?>"><?=ucfirst(strtolower($value['finishLevelName']));?></option>
      <?php } ?>
    </select>
    <p role="alert" class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
  </div>

  <div class="k-select-field row" tabindex="0">
    <label class="k-select-label">Finish Level</label>
    <select class="k-select" id="finish-level-grade">
      <?php foreach ($projectType['finishLevelGradeDetails'] as $key => $value) {?>
        <option value="<?=$value['finishLevelGradeOrganizationId'];?>"><?=ucfirst($value['finishLevelGradeName']);?></option>
      <?php } ?>
    </select>
    <p role="alert" class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
  </div>
</form>
    
    
    <div class="container-estimator-2">
      <button
        id="continue-project"
        type="button"
        class="k-btn-primary k-btn-large">
        Next project
      </button>
    </div>
  </div>