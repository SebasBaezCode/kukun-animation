<div id="selected_projects" class="estimator-d-padding" style="display: none">
  <h5 class="k-text-center view-title view-title-marginb">Your selected projects</h5>
  <div class="projects">
  <?php foreach (Common::getProjectList() as $key => $value) {?>
    <!-- {/* Project Box */} -->
    <div class="project-box" data-id="<?=$value['projectTypeOrganizationId'];?>" style="display: none">
      <p class="project-name">
        <?=ucwords($value['projectName']);?>    
      </p>
      <div class="icon-controls">
        <img src="./assets/img/icons/projects/<?=Common::getName($value['projectName']);?>.svg" alt="Icon" title="" class="icon project-icon" />
        <div class="controls">
          <button type="button" class="rm-btn-styles plus" data-id="<?=$value['projectTypeOrganizationId'];?>">
            <img src="./assets/img/icons/add.svg" alt="Add" title="" class="icon" />
          </button>
          <p class="count" data-id="<?=$value['projectTypeOrganizationId'];?>">1</p>
          <button type="button" class="rm-btn-styles minus" data-id="<?=$value['projectTypeOrganizationId'];?>">
            <img src="./assets/img/icons/delete.svg" alt="Remove" title="" class="icon" />
          </button>
        </div>
      </div>
    </div>
    <!-- {/* Project Box */} -->
    <?php } ?>
   </div>
   <!-- {/* Bottom */} -->
   <div class="container-estimator-2">
      <button 
         id="btn_back_estimate"
         type="button"
         class="k-btn-secondary k-btn-large mb-12">
      Back
      </button>
      <button
         type="button"
         id="create-project"
         class="k-btn-primary k-btn-large">
      Continue
      </button>
   </div>
</div>