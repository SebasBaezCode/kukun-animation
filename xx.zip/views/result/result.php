<div id="result_page">
  <div class="top-address">
      <p class="k-content">
        <?php if($userProperty['validAddress']){?> 
          <?=$userProperty['propertyInfo']['address'].', '.$userProperty['propertyInfo']['city'].', '.$userProperty['propertyInfo']['state'].', '.$userProperty['propertyInfo']['zipCode'];?>
        <?php }else{ ?> 
          <?=$userProperty['propertyInfo']['city'].', '.$userProperty['propertyInfo']['state'].', '.$userProperty['propertyInfo']['zipCode'];?>
        <?php }?>
      </p>
    </div>
    <!-- {/* Total cost */} -->
    <div class="total-cost" tabindex="0">
      <p class="k-h5">Total cost of remodeling projects</p>
      <h6 class="k-h3" id="value_result_cost"><?=Common::displaynum($project['message']['totalEstimatedProjectCost']);?></h6>
      <ul class="cost-list">
        <?php foreach ($resultArray as $key => $value) {?>
            <li><b><?=$value['projectName'];?></b> - <?=Common::displaynum($value['estimatedCost']);?></li>
        <?php }?>
      </ul>
    </div>
    <!-- {/* Edit-Restart */} -->
    <?php if(!is_array($nextProject)){?>
    <div class="edit-restart" >
        <button type="button" class="rm-btn-styles" style="visibility: hidden;">
          <p class="k-content">Edit projects</p>
        </button>
        <button type="button" class="rm-btn-styles" onclick="location.reload();">
          <p class="k-content">Restart estimate</p>
        </button>
    </div> 
    <?php } ?>
  </div>