<div id="home_address" class="estimator-d-padding" style="display: none">
    <h5 class="view-title view-title-marginb k-text-center">What is your home address?</h5>
    <p class="k-text-center k-cta subtitle view-title-marginb">In order to calculate the materials <br />insert your address</p>

    <div class="k-input-field address-input">
      <div class="k-field k-field-icon">
        <input type="text" class="k-input" id="homeAddress" autocomplete="off" placeholder="Address" required />
        <img src="../assets/img/icons/address_zipcode.svg" class="icon-input" alt="Address" />
        <label class="k-input-label">Address</label>
        <input type="hidden" id="googleaddress">
        <input type="hidden" id="address">
        <input type="hidden" id="city">
        <input type="hidden" id="state">
        <input type="hidden" id="zipcode">
      </div>
      <p role="alert" class="k-error k-notifications address-error"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error Address" /> We can’t seem to find the address you typed – please select one from the list of suggestions. </p>
    </div>

    <p class="k-cta k-text-center">
      Your address helps us to calculate the remodeling costs that are specific to your home. Don't want to share it? You can get a rough estimate for the projects <a href="javascript:void(0);" role="button" tabindex="0" class="address-to-zipcode">using zip code</a>
    </p>

    <!-- {/* Bottom */} -->
    <div class="container-estimator-2 bottom-margin70">
      <button
        id="continue-address"
        type="button"
        class="k-btn-primary k-btn-large">
        Continue
      </button>
    </div>
  </div>