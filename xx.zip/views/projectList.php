<div id="project_list" class="estimator-d-padding">
    <div class="projects-header" id="div_projects_header">
        <p class="k-notifications k-text-center start-title">Start your renovation off on the right foot. Know what to
            put in, and what you'll get out.</p>
        <div class="contractors-img">
            <img src="./assets/img/illustrations/contractors.png" alt="Contractors" />
        </div>
    </div>
    <div id="btn_back_less_projects" class="go-back" tabindex="0" role="button">
        <img src="./assets/img/icons/back.svg" alt="Back" title="Back" />
        Go back
    </div>

    <!-- Projects -->
    <div class="container-projects" id="div_container_projects">
        <!-- Button with name Project -->
        <?php foreach (Common::getProjectList() as $key => $value) {?>
            <?php if(in_array($value['projectName'],array("Guest House + Kitchen","Garage","Indoor Swimming Pool","Hallway/Common Area"))){
                continue;
            }?>
            <button class="k-btn-estimator" data-selected="false" data-id="<?=$value['projectTypeOrganizationId'];?>" data-name="<?=$value['projectName'];?>"><?=ucwords($value['projectName']);?></button> 
        <?php }?>
        <input type="hidden" id="total_project_count" value="<?=$key++;?>">
        <input type="hidden" id="selected_project_count" value="1"> 
    </div>

    <div class="show-more-projects container-estimator-2">
        <button 
            type="button"
            disabled="disabled"
            id="btn_start_estimate"
            class="k-btn-large k-btn-disable">
            Start
        </button>
    </div>
</div>