<div id="home_data" style="display: none">
    <div class="top-address">
      <p class="k-content">2211 N First St, San Jose CA 95134</p>
    </div>
    <div class="estimator-d-padding"> 
      <div>
        <div class="k-select-field row">
          <label class="k-select-label">Home type</label>
          <select class="k-select">
            <option value="1">Single family</option>
          </select>
          <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
        </div>
        <div class="k-input-field row">
          <div class="k-field ">
            <input type="text" class="k-input" autocomplete="off" placeholder="Home size" required />
            <label class="k-input-label">Home size</label>
          </div>
          <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
        </div>
        <div class="k-input-field row">
          <div class="k-field ">
            <input type="text" class="k-input" autocomplete="off" placeholder="Home size" required />
            <label class="k-input-label">Home size</label>
          </div>
          <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
        </div>
      </div>

      <!-- {/* Bottom */} -->
      <div class="container-estimator-2 bottom-margin70">
        <button
          type="button"
          class="k-btn-primary k-btn-large">
          Finish
        </button>
      </div>
    </div>
  </div>