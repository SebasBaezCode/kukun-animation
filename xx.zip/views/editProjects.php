<div id="edit_projects" style="display: none">
    <div class="top-address">
      <p class="k-content">2211 N First St, San Jose CA 95134</p>
    </div>

    <div class="estimator-d-padding">
      <h5 class="k-h5 k-text-center m-0">Selects projects that you <br /> want to edit</h5>
      <div class="container-edit-projects">
        <ul class="project-box collapsible">
          <li>
            <div class="collapsible-header">
              <div class="left">
                <img src="../assets/img/icons/projects/2_window_replacement.svg" alt="Icon" />
                <h6 class="k-h6 name-project">Name project</h6>
              </div>
              <div class="right">
                <h6 class="k-h6 cost-project">$5,142</h6>
                <img src="../assets/img/icons/dropdown_grey.svg" alt="Arrow down" />
              </div>
            </div>
            <div class="collapsible-body">
              <div class="k-select-field row">
                <label class="k-select-label">Type of remodel</label>
                <select class="k-select">
                  <option value="1">Renovation</option>
                </select>
                <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
              </div>

              <div class="k-select-field row">
                <label class="k-select-label">Type of remodel</label>
                <select class="k-select">
                  <option value="1">Renovation</option>
                </select>
                <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
              </div>

              <div class="container-estimator-2">
                <button
                  type="button"
                  class="k-btn-primary k-btn-large">
                  Save
                </button>
              </div>
            </div>
          </li>
        </ul>

        <ul class="project-box collapsible">
          <li>
            <div class="collapsible-header">
              <div class="left">
                <img src="../assets/img/icons/projects/2_window_replacement.svg" alt="Icon" />
                <h6 class="k-h6 name-project">Name project</h6>
              </div>
              <div class="right">
                <h6 class="k-h6 cost-project">$5,342</h6>
                <img src="../assets/img/icons/dropdown_grey.svg" alt="Arrow down" />
              </div>
            </div>
            <div class="collapsible-body">
              <div class="k-select-field row">
                <label class="k-select-label">Type of remodel</label>
                <select class="k-select">
                  <option value="1">Renovation</option>
                </select>
                <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
              </div>

              <div class="k-select-field row">
                <label class="k-select-label">Type of remodel</label>
                <select class="k-select">
                  <option value="1">Renovation</option>
                </select>
                <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
              </div>

              <div class="container-estimator-2">
                <button
                  type="button"
                  class="k-btn-primary k-btn-large">
                  Save
                </button>
              </div>
            </div>
          </li>
        </ul>
      </div>

      <!-- {/* Bottom */} -->
      <div class="bottom">
        <p class="load-more">Load more</p>
        <div class="container-estimator-2">
          <button
            type="button"
            class="k-btn-secondary k-btn-large">
            Back
          </button>
          <br />
          <button
            type="button"
            class="k-btn-primary k-btn-large">
            View loan offers
          </button>
        </div>
      </div>
    </div>
  </div>