<div id="result_page" style="display: none">
</div>