<div id="sub_total" style="display: none">
    <div class="total-cost">
        <p class="k-content">Total cost of remodeling<br /> your kitchen is</p>
        <h6 class="k-h3" id="value_total_cost">$25,000</h6>
    </div>
</div>