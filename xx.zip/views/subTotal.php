<div id="sub_total" style="display: none">
    <div class="total-cost">
        <p class="k-content">Total cost of remodeling<br /> your kitchen is</p>
        <h6 class="k-h3" id="value_total_cost">$25,000</h6>
    </div>
    <div class="estimator-d-padding">
      <h5 class="k-h5 view-title k-text-center">Estimate exterior painting cost</h5>
      <div class="k-select-field row">
        <label class="k-select-label">Condition of walls?</label>
        <select class="k-select">
          <option value="1">Older walls with peeling paint</option>
        </select>
        <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
      </div>
      <div class="k-select-field row">
        <label class="k-select-label">Extent of visible peeling?</label>
        <select class="k-select">
          <option value="1">Some obvious peeling</option>
        </select>
        <p class="k-error k-notifications"> <img src="../assets/img/icons/error.svg" class="icon-error" alt="Error" /> Error error</p>
      </div>

      <!-- {/* Bottom */} -->
      <div class="container-estimator-2 bottom-margin70">
        <button
          type="button"
          class="k-btn-primary k-btn-large">
          Next project
        </button>
      </div>
    </div>
</div>