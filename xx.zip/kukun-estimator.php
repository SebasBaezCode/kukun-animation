<?php  include_once './service/common.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/main.min.css">
    <title>Document</title>
</head>
<body>

    <div class="k-container-full bg-estimator" role="main">
        <div class="container-company-logo">
            <img src="./assets/img/icons/company_logo.svg" class="company-logo" alt="Company logo"> 
        </div>
        <div class="kukun-estimator">
            <input type="hidden" id="project-obj">
            <?php  include_once 'views/projectList.php'; ?>
            <?php  include_once 'views/selectedProjects.php'; ?>
            <?php  include_once 'views/estimateOptions.php'; ?>
            <?php  include_once 'views/zipCode.php'; ?>
            <?php  include_once 'views/resultPage.php'; ?>
            <?php  include_once 'views/homeAddress.php'; ?>
            <div class="container-poweredby">
                <a href="#" target="_blank" tabindex="0">
                    <img src="./assets/img/icons/poweredBy.svg" class="powered-by" alt="Powered By Kukun"> 
                </a>
            </div>
        </div>
    </div>

    <script src="./assets/js/jquery-3.5.1.min.js"></script>
    <script src="./assets/js/materialize.min.js"></script>
    <script src="./assets/js/select2.min.js"></script>
    <script>
        $(document).ready(function(){
            $('.collapsible').collapsible();
            $('body').on('keyup', '.only-number', function(event) {
                var value = $(this).val();
                value = value.replace(/^(0*)/,"");
                $(this).val(value);
                if (/\D/g.test(this.value)) {
                    this.value = this.value.replace(/\D/g, '');

                }
            });

            $('body').on('input', '.only-number', function(event) {
                var value = $(this).val();
                value = value.replace(/^(0*)/,"");
                $(this).val(value);
                if (/\D/g.test(this.value)) {
                    this.value = this.value.replace(/\D/g, '');

                }
            });
            
        });
        // For Select2 - JAWS issue fixed
        $("body").on('keyup', ".select2,.select2-dropdown", function (e) {
            var KEYS = { UP: 38, DOWN: 40 };
            var $sel2 = $(this).closest(".select2");
            // if we can't find it by traveersing the dom, search page for an open container
            // ASSUMES only one open at a time - 
            // don't really know how to cross walk from dropdown back to coresponding element
            if ($sel2.length == 0) {
                $sel2 = $(".select2.select2-container--open");
            }

            // make sure we found the <select> el
            var $sel = $sel2.data("element")
            if ($sel.length) {
                var newValue

                if (e.keyCode === KEYS.DOWN && !e.altKey) {
                    newValue = $sel.find('option:selected').nextAll(":enabled").first().val();
                } else if (e.keyCode === KEYS.UP) {
                    newValue = $sel.find('option:selected').prevAll(":enabled").first().val();
                }

                // if we got a value, set it and update
                if (newValue != undefined) {
                    $sel.val(newValue);
                    $sel.trigger('change');
                }
             }
            });
            $("body").on('keydown', ".select2,.select2-dropdown", function (e) { // For MacOS "Ctrl+option+space_bar"
                if (e.ctrlKey && e.altKey && e.keyCode == 32) {
                    var select2_element = $(this)[0].parentNode.querySelector('span.select2-container');
                    select2_element.classList.add('select2-container--open');
                }
            })
    </script>
    <script type="text/javascript" src="./assets/js/projectList.js?v=<?=$params['version'];?>"></script>
    <script type="text/javascript" src="./assets/js/estimation-room.js?v=<?=$params['version'];?>"></script>
    <script type="text/javascript" src="./assets/js/zip-code.js?v=<?=$params['version'];?>"></script>
    <script type="text/javascript" src="./assets/js/address.js?v=<?=$params['version'];?>"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=<?=$params['google_map_key'];?>&libraries=places&callback=lisgoosearch&language=en" type="text/javascript"></script>
    
</body>
</html>

