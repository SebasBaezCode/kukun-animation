<?php 
include_once 'service/common.php';
$googleUrl = 'https://maps.googleapis.com/maps/api/geocode/json?components=postal_code:'.$_GET['zip-code'].'|country:US&key='.$params['google_map_key'];
$address = Common::getGoogleAddressByZipCode($googleUrl);
echo json_encode($address);
?>