<?php
define('PARAMS', require_once 'params.php');
define('ESTIMATION_URL', PARAMS['estimationservicelink']);
define('HEADERS', [
    'Content-Type: application/json',
    'Accept: application/json',
    ''. PARAMS['organization-key-name'].':' . ''.PARAMS['organization-api-key'].'',
    'access-token: 52d7ba81ab5f871331c95d28dafa7a40'
]);

require_once './functions.php';

if (isset($_GET['action'])) {
    $ACTION = $_GET['action'];

    if ($ACTION == 'getProjects') {
        getProjects();
    }
}