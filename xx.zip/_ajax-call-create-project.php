<?php 
include_once 'service/common.php';
$projectObj  	= Common::postProjectObj($_POST['projectList']);
//print_r($projectObj);die;
$projectType 	= Common::getProjectTypeById($projectObj['projectTypeId']);

if(is_array($projectType)){
	$projectRoomConfigurations = $projectType['projectRoomConfigurations'];
	include_once 'views/projectOption/roomProject.php';
}
?>