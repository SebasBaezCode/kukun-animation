<?php
class Config{
  
    // credentials
    private $organizationToken;
    private $kukunApiUrl;

    public function __construct(){
        global $params;
        $this->organizationToken = $params["organization-api-key"];
        $this->kukunApiUrl = $params["estimationservicelink"];
    }
  
    // get the from api
    public function kukunHTTPRequest($url,$method,$post=array(),$accessToken = ''){
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$this->kukunApiUrl.$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch,CURLOPT_FAILONERROR, true); 


        $headers = [
            'organization-api-key: '.$this->organizationToken,
            'Accept: application/json',
            'Content-Type: application/json'
        ];

        if($accessToken != ''){
            $headers[] = 'access-token:'.$accessToken;
        }
        
        if($method == 'POST'){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
        }

        if($method == 'PUT'){
            //print_r(json_encode($post));die;
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
        }



        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);

        $output=curl_exec($ch);
        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
        }
        curl_close($ch);
        if (isset($error_msg)) {
                print_r("Error:- ".$error_msg);die;
        }
        return json_decode($output, true);
    }

    public function externalCurl($url,$method,$post=array()){
        $ch = curl_init();  
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        if($method == 'POST'){
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
        }
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        $output=curl_exec($ch);
        curl_close($ch);
        return json_decode($output, true);
    }
}
?>