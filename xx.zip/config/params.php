<?php
$servername =  $_SERVER['SERVER_NAME'];
$params =array(
    'organization-api-key' => '162d430a9855c377c3572b39e797e6cd',
    'google_map_key' => 'AIzaSyCsij1cQ0SG_aV97k3OJ_-fP62NeZ1aQfo',
    'organization-key-name' => 'organization-api-key',
    'access-token-name' => 'access-token',
    'estimationservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-estimation/',
    'roiservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-roi/',
    'securityservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-security/',
    'professionalservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-professional/',
    'smartsearchservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-smart-search/',
    'loanservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-loan/',
    'auditservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-audit/',
    'notificationservicelink' => 'https://apiservicesdev.mykukun.com:8072/api/kukun-notification/',
    'version' => '6',
);