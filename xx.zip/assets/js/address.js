	
	function lisgoosearch() {
            
            autocomplete = new google.maps.places.Autocomplete(
                    /** @type {HTMLInputElement} */ (document.getElementById('homeAddress')), {
                        types: ['geocode'],
                        componentRestrictions: {country: "us"},
                        regions: "postal_code"
                    });
            
            autocomplete.addListener('place_changed', function() {
                search();
            });

            function search(){

                        var addr = {};
						$('.address-input').removeClass('k-field-error');
						
						$('#address').val('');
                        $('#city').val('');
                        $('#state').val('');
                        $('#zipcode').val('');
						
						$('#googleaddress').val($('#homeAddress').val());
                        place = autocomplete.getPlace();
                        var address = '';
                       //console.log("google place",place);
                       for (var i = 0; i < place.address_components.length; i++){
                            var street_number = route = street = city = state = zipcode = country = formatted_address = '';
                            var types = place.address_components[i].types.join(",");
                            
                            console.log("-->", types);

                            if (types == "street_number"){
                              addr.street_number = place.address_components[i].long_name;
                              address += place.address_components[i].long_name+' ';
                            }
                            if (types == "route" || types == "point_of_interest,establishment"){
                              addr.route = place.address_components[i].long_name;
                              address += place.address_components[i].long_name+' ';
                            }
                            
                            if (types == "locality,political" || types == "sublocality_level_1,sublocality,political" || types == "administrative_area_level_3,political"){
                              addr.city = (city == '' || types == "locality,political") ? place.address_components[i].long_name : city;
                            }

                            if(types == "administrative_area_level_2,political") {
                                addr.county = place.address_components[i].short_name;
                            }

                            if (types == "administrative_area_level_1,political"){
                              addr.state = place.address_components[i].short_name;
                            }
                            if (types == "postal_code" || types == "postal_code_prefix,postal_code"){
                              addr.zipcode = place.address_components[i].long_name;
                            }
                            if (types == "country,political"){
                              addr.country = place.address_components[i].long_name;
                              if(place.address_components[i].long_name == "United States") {
                              } else {
                                return false;
                              }
                            }
                        }
                        $('#address').val(address);
                        $('#city').val(addr.city);
                        $('#state').val(addr.state);
                        $('#zipcode').val(addr.zipcode);
                        console.log("final", addr);
            }
        }

	
	
	$('.address-to-zipcode').click(function(){
		$('#zip_code').show();
		$('#home_address').hide();
		
	});	
	
	$('body').on('keyup', '#homeAddress', function(event) {
		if (event.keyCode == 13) {
			$('#continue-address').trigger('click');
		}
	});
	
	$('#continue-address').click(function(){
		
		if($('#googleaddress').val() == '') {
			console.log('error');
			$('.address-input').addClass('k-field-error');
			return false;
		}
		if($('#googleaddress').val() != $('#homeAddress').val()) {
			console.log('error');
			$('.address-input').addClass('k-field-error');
			return false;
		}
		
		if($('#address').val() == '' || $('#city').val() == '' || $('#state').val() == '' || $('#zipcode').val() == ''){
			console.log('error');
			$('.address-input').addClass('k-field-error');
			return false;
		}
		
		$('.address-input').removeClass('k-field-error');
		var obj={};
		var userProperty = {};
		userProperty.userPropertyId = $('#userPropertyId').val();
		userProperty.validAddress = true;
		userProperty.propertyInfo={};
		userProperty.propertyInfo.zipCode = $('#zipcode').val();
		userProperty.propertyInfo.address = $('#address').val();
		userProperty.propertyInfo.state   = $('#state').val();
		userProperty.propertyInfo.city    = $('#city').val();
		obj.userProperty = userProperty;
		obj.accessToken = $('#accessToken').val();
		$(this).html('Please wait..');
		$(this).attr('disabled','disabled');
		$(this).addClass('k-btn-disable');
		$.ajax({
			url: '_ajax-call-update-property.php',
			dataType: 'json',
			type: 'post',
			data: {"obj":obj},
			success: function( data, textStatus, jQxhr ){
				console.log("data",data);
				if(data.success){
					var projectObj={};
					projectObj.project 		= $.parseJSON($('#project-obj').val());
					projectObj.accessToken  = $('#accessToken').val();
					$.ajax({
						url: '_ajax-call-update-project.php',
						dataType: 'html',
						type: 'post',
						data: {"obj":projectObj},
						success: function( data, textStatus, jQxhr ){
							console.log("data",data);
							$('#home_address').hide();
							$('#estimate_option_div').show();
							$('#estimate_option_div').html(data);
							$('.k-select').select2({
								minimumResultsForSearch: -1,
								width: '100%'
							});
						},
						error: function( jqXhr, textStatus, errorThrown ){
							
						}
					});
				}
			},
			error: function( jqXhr, textStatus, errorThrown ){
				
			}
		});
	});