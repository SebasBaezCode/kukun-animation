$( document ).ready(function() {
	var zipCodeError =false;

    $('#zip-code').keyup(function(){
		$('#zip_code').removeClass('k-field-error');
		console.log("zip-code inner");
		if($(this).val().length >= 5){
			console.log("zip-code > 5");
			$.ajax({
			url: '_ajax-call-zip-code.php?zip-code='+$(this).val(),
			dataType: 'json',
			type: 'get',
			success: function( data, textStatus, jQxhr ){
				console.log("zip-code data",data);
				if(data.status != 'OK'){
					zipCodeError =true;
					$('#zip_code').addClass('k-field-error');
				}else{
					zipCodeError =false;
					$('#zip_code').removeClass('k-field-error');
				}
			},
			error: function( jqXhr, textStatus, errorThrown ){
				console.log("error data",data);
			}
		});
		}else{
			zipCodeError =true;
		}
	});
	
	$('.full-address').click(function(){
		$('#zip_code').hide();
		$('#home_address').show();
		
	});	
	
	$('body').on('keyup', '#zip-code', function(event) {
		if (event.keyCode == 13) {
			$('#continue-zip-code').trigger('click');
		}
		var value = $(this).val();
        $(this).val(value);
        if (/\D/g.test(this.value)) {
            this.value = this.value.replace(/\D/g, '');
        }
	});
	
	$('body').on('input', '#zip-code', function(event) {
		if (event.keyCode == 13) {
			$('#continue-zip-code').trigger('click');
		}
		var value = $(this).val();
        $(this).val(value);
        if (/\D/g.test(this.value)) {
            this.value = this.value.replace(/\D/g, '');
        }
	});
	
	
	
	$('#continue-zip-code').click(function(){
		if(zipCodeError){
			console.log('error');
			console.log('zipCodeError');
			$('#zip_code').addClass('k-field-error');
			return false;
		}
		if($('#zip-code').val() == ''){
			console.log('error');
			console.log('null');
			$('#zip_code').addClass('k-field-error');
			return false;
		}
		
		if($('#zip-code').val().length != 5){
			console.log('error');
			console.log('length');
			$('#zip_code').addClass('k-field-error');
			return false;
		}
		
		$('#zip_code').removeClass('k-field-error');
		
		$(this).html('Please wait..');
		$(this).attr('disabled','disabled');
		$(this).addClass('k-btn-disable');
		var obj={};
		var userProperty = {};
		userProperty.userPropertyId = $('#userPropertyId').val();
		userProperty.propertyInfo = {"zipCode" :  $('#zip-code').val()};
		obj.userProperty = userProperty;
		obj.accessToken = $('#accessToken').val();
		$.ajax({
			url: '_ajax-call-update-property.php',
			dataType: 'json',
			type: 'post',
			data: {"obj":obj},
			success: function( data, textStatus, jQxhr ){
		debugger;

				console.log("data",data);
				if(data.success){
					var projectObj={};
					projectObj.project 		= $.parseJSON($('#project-obj').val());
					projectObj.accessToken  = $('#accessToken').val();
					$.ajax({
						url: '_ajax-call-update-project.php',
						dataType: 'html',
						type: 'post',
						data: {"obj":projectObj},
						success: function( data, textStatus, jQxhr ){
							console.log("data",data);
							$('#zip_code').hide();
							$('#estimate_option_div').show();
							$('#estimate_option_div').html(data);
							$('.k-select').select2({
								minimumResultsForSearch: -1,
								width: '100%'
							});
						},
						error: function( jqXhr, textStatus, errorThrown ){
							
						}
					});
				}
			},
			error: function( jqXhr, textStatus, errorThrown ){
				
			}
		});
	});
	
		
});