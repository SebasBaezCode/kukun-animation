$( document ).ready(function() {
	var projectObj =[];
    $('.k-btn-estimator').click(function(){
		var id = $(this).attr('data-id');
		if($(this).attr('data-selected') == 'false'){
			$(this).addClass('k-btn-estimator-active');
			$(this).attr('data-selected','true');
			$('#selected_project_count').val($('#selected_project_count').val()*2);
			addProject(id);
		}else{
			$(this).removeClass('k-btn-estimator-active');
			$(this).attr('data-selected','false');
			$('#selected_project_count').val($('#selected_project_count').val()/2);
			removeProject(id);
		}
		
		if($('#selected_project_count').val() != 1){
			$('#btn_start_estimate').addClass('k-btn-primary');
			$('#btn_start_estimate').removeClass('k-btn-disable');
			$('#btn_start_estimate').removeAttr('disabled','');
		}else{
			$('#btn_start_estimate').removeClass('k-btn-primary');
			$('#btn_start_estimate').addClass('k-btn-disable');
			$('#btn_start_estimate').attr('disabled','disabled');
		}
		$('.project-box[data-id="'+id+'"]').toggle();
			
	});
	
	$('#btn_start_estimate').click(function(){
		$('#project_list').hide();
		$('#selected_projects').show();
		var obj = [];
		$('.k-btn-estimator').each(function( index ) {
			if($(this).attr('data-selected') == 'true'){
				obj.push({'id': $(this).attr('data-id'),'name': $(this).attr('data-name')});
			}
		});
		console.log("obj",obj);
	});
	
	$('#btn_back_estimate').click(function(){
		$('#project_list').show();
		$('#selected_projects').hide();
		projectObj =[];
		
		$('.k-btn-estimator').each(function( index ) {
			if($(this).attr('data-selected') == 'true'){
				projectObj.push($(this).attr('data-id'));
			}
		});
		$('.count').html('1');
		console.log("projectObj",projectObj);
	});
	
	$('.plus').click(function(){
		var id = $(this).attr('data-id');
		addProject(id);
		var count = $('.count[data-id="'+id+'"]').html();
		count++;
		$('.count[data-id="'+id+'"]').html(count);
	});
	
	$('.minus').click(function(){
		var id = $(this).attr('data-id');
		var count = $('.count[data-id="'+id+'"]').html();
		if(count == '1'){
			console.log("count",count);
			return;
		}
		removeProject(id);
		count--;
		$('.count[data-id="'+id+'"]').html(count);
	});
	
	$('#create-project').click(function(){
		console.log("projectObj",projectObj);
		
		var obj={};
		obj.projectList = projectObj;
		$(this).html('Please wait..');
		$(this).attr('disabled','disabled');
		$(this).addClass('k-btn-disable');
		$.ajax({
			url: '_ajax-call-create-project.php',
			dataType: 'html',
			type: 'post',
			data: obj,
			success: function( data, textStatus, jQxhr ){
				$('#selected_projects').hide();
				$('#estimate_option_div').show();
				$('#estimate_option_div').html(data);
				$('.k-select').select2({
					minimumResultsForSearch: -1,
					width: '100%'
				});
			},
			error: function( jqXhr, textStatus, errorThrown ){
				
			}
		});
	});
	
	function addProject(id){
		projectObj.push(id);
		console.log("projectObj",projectObj);
	}
	
	function removeProject(id){
		var index = projectObj.indexOf(id);
		projectObj.splice(index, 1);
		console.log("projectObj",projectObj);
	}
		
});