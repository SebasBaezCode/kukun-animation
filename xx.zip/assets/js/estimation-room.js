	$('body').on('change', '#renovation-type', function(event) {
		console.log("renovation-type");
		if($('#renovation-type :selected').text() == 'Addition'){
			$('.addition').show();
			$('.non-addition').hide();
			$('#finish-level').prop('selectedIndex',2).attr('disabled','disabled').trigger('change');
			$('#additional-type').prop('selectedIndex',0);
		}else{
			$('.addition').hide();
			$('.non-addition').show();
			$('#finish-level').prop('selectedIndex',0).removeAttr('disabled').trigger('change');
		}
		
		if($('#renovation-type :selected').text() == 'Expansion'){
			console.log("Expansion-type");
			$('.expansion').show();
			$('#expansion-type').prop('selectedIndex',0).trigger('change');
		}else{
			$('.expansion').hide();
		}
		$('#size-of-addition').val('');
		$('#size-of-expansion').val('');
		console.log("end renovation-type");
		
	});

	$('body').on('keyup', '.only-number', function(event) {
		$('.custom-sqft-text-box').removeClass('k-field-error');
		$('.custom-length-text-box').removeClass('k-field-error');
		$('.custom-width-text-box').removeClass('k-field-error');
		$('.custom-feet-text-box').removeClass('k-field-error');
		$('.expansion-text-box').removeClass('k-field-error');
		$('.addition-text-box').removeClass('k-field-error');
	});
	
	$('body').on('change', '#project-unit-feet, #project-unit', function(event) {
		$('.custom-sqft-text-box').removeClass('k-field-error');
		$('.custom-length-text-box').removeClass('k-field-error');
		$('.custom-width-text-box').removeClass('k-field-error');
		$('.custom-feet-text-box').removeClass('k-field-error');
		$('.expansion-text-box').removeClass('k-field-error');
		$('.addition-text-box').removeClass('k-field-error');
		$('#custom-length-size').val('');
		$('#custom-width-size').val('');
		$('#custom-sqft-size').val('');
	});
	
	$('body').on('keyup', '#estimate_options .only-number', function(event) {
		if (event.keyCode == 13) {
			$('#continue-project').trigger('click');
		}
	});
	
	
	
	$('body').on('change', '#expansion-type', function(event) {
		if($(this).prop('selectedIndex') == 0){
			$('#finish-level').prop('selectedIndex',2).attr('disabled','disabled').trigger('change');
		}else{
			$('#finish-level').prop('selectedIndex',0).removeAttr('disabled').trigger('change');
		}
	});
	
	$('body').on('change', '.select-size', function(event) {
		if($('.sqft-check').is(':checked')){
			var length = $('#project-unit-feet option:selected').attr('data-length');
			var width  = $('#project-unit-feet option:selected').attr('data-width');
			if(length == '0' && width == '0'){
				console.log("custom");
				$('.feet-input').show();
			}else{
				console.log("non-custom");
				$('.feet-input').hide();
			}
		}else{
			var length = $('#project-unit option:selected').attr('data-length');
			var width  = $('#project-unit option:selected').attr('data-width');
			console.log("length", length);		
			if(length == '0' && width == '0'){
				console.log("custom");
				$('.sqfeet-input').show();
			}else{
				console.log("non-custom");
				$('.sqfeet-input').hide();
			}
		}
	});	

	$('body').on('change', '.sqft-check', function(event) {
		var length 	= $('#project-unit option:selected').attr('data-length');
		var width  	= $('#project-unit option:selected').attr('data-width');
		var total 	= length*width;
		
		$(".sqfeet").toggle();
		$(".feet").toggle();
		$('#project-unit').prop('selectedIndex',0);
		$('#project-unit-feet').prop('selectedIndex',0);
		
		$('.sqfeet-input').hide();
		$('.feet-input').hide();
		
		$('.select-size').trigger('change');
	});

	$('body').on('click', '#continue-project', function(event) {
		var length		= 0;
		var width 		= 0;
		var totalUnit 	= 0;
		var sqfeet 		= 'feet';
		var unitId;
		var addition 	= null;
		var expansion 	= null;
		
		//validation
		if($('#renovation-type :selected').text() == 'Addition'){
			if($('#size-of-addition').val() == ''){
				$('.addition-text-box').addClass('k-field-error');
				$('#size-of-addition').focus();
				$('.size-of-addition-error span').html('Please enter the size of addition to continue');
				return false;
			}else if($('#size-of-addition').val() < 49){
				$('.addition-text-box').addClass('k-field-error');
				$('#size-of-addition').focus();
				$('.size-of-addition-error  span').html('The size of addition cannot be less than 49 sq. ft.');
				return false;
			}else if($('#size-of-addition').val() > 5000){
				$('.addition-text-box').addClass('k-field-error');
				$('#size-of-addition').focus();
				$('.size-of-addition-error  span').html('The size of addition cannot exceed 5,000 sq. ft');
				return false;
			}else{
				$('.addition-text-box').removeClass('k-field-error');
				totalUnit 	= $('#size-of-addition').val();
				sqfeet 		= 'sqfeet';
				addition 	= {};
				addition.id = $('#additional-type').val();
				unitId 		= $('#customId').val();
			}
		}else if($('#renovation-type :selected').text() == 'Expansion'){
			
			if($('#size-of-expansion').val() == ''){
				$('.expansion-text-box').addClass('k-field-error');
				$('#size-of-expansion').focus();
				$('.size-of-expansion-error  span').html('Please enter the size of expansion to continue');
				return false;
			}else if($('#size-of-expansion').val() < 49){
				$('.expansion-text-box').addClass('k-field-error');
				$('#size-of-expansion').focus();
				$('.size-of-expansion-error  span').html('The size of expansion cannot be less than 49 sq. ft.');
				return false;
			}else if($('#size-of-expansion').val() > 5000){
				$('.expansion-text-box').addClass('k-field-error');
				$('#size-of-expansion').focus();
				$('.size-of-expansion-error  span').html('The combined size of expansion and the existing room cannot exceed 5,000 sq.ft.');
				return false;
			}else{
				$('.expansion-text-box').removeClass('k-field-error');
			}
		}
		
		
		if($('.sqft-check').is(':checked') && $('#renovation-type :selected').text() != 'Addition'){
			length = $('#project-unit-feet option:selected').attr('data-length');
			width  = $('#project-unit-feet option:selected').attr('data-width');
			unitId = $('#project-unit-feet').val();
			if(length == '0' && width == '0'){
				length 	= $('#custom-length-size').val();
				width 	= $('#custom-width-size').val();
				if($('#custom-length-size').val() == '' || $('#custom-width-size').val() == ''){
					if($('#custom-width-size').val() == ''){
						$('.custom-width-text-box').addClass('k-field-error');
						$('#custom-width-size').focus();
						$('.custom-width-size-error').show();
						$('.custom-width-size-error  span').html('Please enter the custom width.');
					}
					if($('#custom-length-size').val() == ''){
						$('.custom-length-text-box').addClass('k-field-error');
						$('#custom-length-size').focus();
						$('.custom-length-size-error  span').html('Please enter the custom length');
					}
					return false;
				}else if($('#custom-length-size').val() < 7){
					$('.custom-length-text-box').addClass('k-field-error');
					$('#custom-length-size').focus();
					$('.custom-length-size-error  span').html('The length of the room cannot be less than 7 ft.');
					return false;
				}else if($('#custom-width-size').val() < 7){
					$('.custom-width-text-box').addClass('k-field-error');
					$('#custom-width-size').focus();
					$('.custom-width-size-error  span').html('The width of the room cannot be less than 7 ft.');
					return false;
				}else if(($('#custom-length-size').val()*$('#custom-width-size').val()) >= 5000){
					$('.custom-feet-text-box').addClass('k-field-error');
					$('.custom-feet-size-error').show();
					$('.custom-feet-size-error  span').html('The size of your space cannot exceed 5,000 sq. ft');
					return false;
				}else{
					$('.custom-length-text-box').removeClass('k-field-error');
					$('.custom-width-text-box').removeClass('k-field-error');
					$('.custom-feet-text-box').removeClass('k-field-error');
				}
			}
			totalUnit = length*width;
		}else if($('#renovation-type :selected').text() != 'Addition'){
			length = $('#project-unit option:selected').attr('data-length');
			width  = $('#project-unit option:selected').attr('data-width');
			sqfeet = 'sqfeet';
			unitId = $('#project-unit').val();
			console.log("unitId",unitId);
			if(length == '0' && width == '0'){
				totalUnit 	= $('#custom-sqft-size').val();
				if(totalUnit == ''){
					$('.custom-sqft-text-box').addClass('k-field-error');
					$('#custom-sqft-size').focus();
					$('.custom-sqft-size-error  span').html('Please enter the custom square footage to continue');
					return false;
				}else if(totalUnit < 49){
					$('.custom-sqft-text-box').addClass('k-field-error');
					$('#custom-sqft-size').focus();
					$('.custom-sqft-size-error span').html('Room size cannot be less than 49 sq. ft.');
					return false;
				}else if(totalUnit > 5000){
					$('.custom-sqft-text-box').addClass('k-field-error');
					$('#custom-sqft-size').focus();
					$('.custom-sqft-size-error span').html('Room size cannot be more than 5,000 sq. ft.');
					return false;
				}else{
					$('.custom-sqft-text-box').removeClass('k-field-error');
				}
			}else{
				totalUnit = length*width;
			}
		}
		
		if($('#renovation-type :selected').text() == 'Expansion'){
			totalUnitExpansion = parseInt(totalUnit) + parseInt($('#size-of-expansion').val());
			console.log("totalUnitExpansion",totalUnitExpansion);
			if( totalUnitExpansion > 5000){
				$('.expansion-text-box').addClass('k-field-error');
				$('#size-of-expansion').focus();
				$('.size-of-expansion-error  span').html('The combined size of expansion and the existing room cannot exceed 5,000 sq.ft.');
				return false;
			}else{
				$('.expansion-text-box').removeClass('k-field-error');
			}
			expansion 				 = {};
			expansion.id 			 = $('#expansion-type').val();
			expansion.additionalSize =  $('#size-of-expansion').val();
		}
		
		
		var projectUnit 		= {};
		projectUnit.projectUnitOrganizationId 	= unitId;
		projectUnit.projectUnitLength 			= length;
		projectUnit.projectUnitWidth 			= width;
		projectUnit.projectUnitTotalUnit 		= totalUnit;
		projectUnit.sizeType 					= sqfeet;
		
		
		console.log("length",length);
		console.log("width",width);
		console.log("sqfeet",sqfeet);
		console.log("totalUnit",totalUnit);
		console.log("addition",addition);
		console.log("expansion",expansion);
		
		$(this).html('Please wait..');
		$(this).attr('disabled','disabled');
		$(this).addClass('k-btn-disable');
		if(getProjectObject(addition,expansion,projectUnit)){
			if($('#propertyId').val() == 1 ){//first project need to ask address
				$('#zip_code').show();
				$('#estimate_option_div').hide();
			}else{
				var projectObj={};
					projectObj.project 		= $.parseJSON($('#project-obj').val());
					projectObj.accessToken  = $('#accessToken').val();
					debugger;
					$.ajax({
						url: '_ajax-call-update-project.php',
						dataType: 'html',
						type: 'post',
						data: {"obj":projectObj},
						success: function( data, textStatus, jQxhr ){
							console.log("data",data);
							$('#estimate_option_div').show();
							$('#estimate_option_div').html(data);
							$('.k-select').select2({
								minimumResultsForSearch: -1,
								width: '100%'
							});
						},
						error: function( jqXhr, textStatus, errorThrown ){
							
						}
					});
			}
		}
	});
	
	
	function getProjectObject(addition,expansion,projectUnit){
		
		var obj = {
				  "userProperty": {
					"userPropertyId": $('#userPropertyId').val(),
				  },
				  "projects": [
					{
					  "projectId": $('#projectId').val(),
					  "projectTypeOrganizationId":$('#projectTypeOrganizationId').val(),
					  "projectConfiguredValue": {
						"estimationType": {
						  "id": $('#renovation-type').val()
						},
						"expansionType": expansion != '' ? expansion : null,
						"additionType": addition != '' ? addition : null,
						"finishLevel": {
						  "finishLevelOrganizationId": $('#finish-level').val()
						},
						"finishLevelGrade": {
						  "finishLevelGradeOrganizationId": $('#finish-level-grade').val()
						},
						"projectUnit": projectUnit,
					  }
					}
				  ],
				  "calculateProject": true,
				  "calculateRoi": false,
				  "returnNoProjectList": false
				};
		console.log("obj",obj);
		$('#project-obj').val(JSON.stringify(obj));
		return true;
	}
	
