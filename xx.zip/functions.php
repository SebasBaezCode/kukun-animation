<?php
function getProjects() {
    $url = ESTIMATION_URL . '/project-types?type=room';
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_HTTPHEADER, HEADERS);
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    
    echo $response;
    curl_close($ch);
}

function basicPostQuery() {
    $url = '';
    $postParams = array(
        "estimationType" => "Renovation",
        "finishLevelId" => "default",
        "limit" => 3,
        "zipCode" => "98104"
    );
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postParams));
    curl_setopt($ch, CURLOPT_HTTPHEADER, HEADERS);
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    
    echo $response;
    curl_close($ch);
}