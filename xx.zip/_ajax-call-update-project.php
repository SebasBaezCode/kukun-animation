<?php 
include_once 'service/common.php';
$projectObj  = $_POST['obj'];

if($projectObj['project']['projects'][0]['projectConfiguredValue']['expansionType'] == ''){
	unset($projectObj['project']['projects'][0]['projectConfiguredValue']['expansionType']);
}

if($projectObj['project']['projects'][0]['projectConfiguredValue']['additionType'] == ''){
	unset($projectObj['project']['projects'][0]['projectConfiguredValue']['additionType']);
}

$project  	 		 = Common::updateProject($projectObj['project'],$projectObj['accessToken']);

if($project['success']){
	$nextProject = false;
	$resultArray = array();
	foreach ($project['message']['projects'] as $key => $value) {
		if($value['projectStatus']){
			$resultArray[] = $value;
		}else if(!$nextProject){
			$nextProject = $value;
		}	
	}
	$userProperty = $project['message']['userProperty'];
	include_once 'views/result/result.php';
	if($nextProject){
        $projectObj['userPropertyId'] = $project['message']['userProperty']['userPropertyId'];
        $projectObj['propertyId']     = $project['message']['userProperty']['propertyInfo']['propertyId'];   
        $projectObj['projectTypeId']  = $nextProject['projectTypeOrganizationId']; 
        $projectObj['projectId']      = $nextProject['projectId'];
		$projectType 	= Common::getProjectTypeById($nextProject['projectTypeOrganizationId']);
		if(is_array($projectType)){
			$projectRoomConfigurations = $projectType['projectRoomConfigurations'];
			include_once 'views/projectOption/roomProject.php';
		}
	}
}

?>