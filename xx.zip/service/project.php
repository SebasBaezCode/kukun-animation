<?php
include_once './config/config.php';
class project {
  
    private $url;
  
    // get the database connection
    public function postProject($projectSelected){
        $this->url      = "projects";
        $con            = new Config();
        $projectObj     = $this->postProjectObj($projectSelected);
        $projectTypes   = $con->kukunHTTPRequest($this->url,'POST',$projectObj);

        if($projectTypes['success']){
            
            $response['accessToken']    = $projectTypes['additionalData']['accessToken'];
            $response['userPropertyId'] = $projectTypes['message']['userProperty']['userPropertyId'];
            $response['propertyId']     = $projectTypes['message']['userProperty']['propertyInfo']['propertyId'];   
            $response['projectTypeId']  = $projectTypes['message']['projects'][0]['projectTypeOrganizationId']; 
            $response['projectId']      = $projectTypes['message']['projects'][0]['projectId'];
        }
        $response['success']            = $projectTypes['success'];
        return $response; 
    }

    public function getProjectTypeById($projectTypeOrganizationId){
        $this->url = "project-types/$projectTypeOrganizationId";
        $con = new Config();
        $projectTypes = $con->kukunHTTPRequest($this->url,'GET');
        return $projectTypes;
    }

    public function postProjectObj($projectSelected){
        $projectObj                                                 = array();
        $projectObj['userProperty']['propertyInfo']['propertyId']   = 1;

        $project = array();
        foreach ($projectSelected as $key => $value) {
            $project[]['projectTypeOrganizationId'] = $value;
        }
        $projectObj['projects']         = $project;
        $projectObj['calculateProject'] = false;
        $projectObj['calculateRoi']     = false;
        return $projectObj;
    }

    public function updateProject($projectObj,$accessToken){
        $this->url  = "projects";
        $con        = new Config();
        //print_r(json_encode($projectObj));die;
        $project    = $con->kukunHTTPRequest($this->url,'PUT',$projectObj,$accessToken);
        return $project;
    }
}
?>