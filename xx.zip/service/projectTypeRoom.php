<?php
// include database and object files
include_once './config/config.php';
class ProjectTypeRoom {
  
    private $url;
  
    // get the database connection
    public function getProjectTypeRoom(){
        $this->url = "project-types?type=room&only-project-type=true";
        $con = new Config();
        $projectTypes = $con->kukunHTTPRequest($this->url,'GET');
        return $projectTypes; 
    }

    public function getProjectTypeById($projectTypeOrganizationId){
        $this->url = "project-types/$projectTypeOrganizationId";
        $con = new Config();
        $projectTypes = $con->kukunHTTPRequest($this->url,'GET');
        return $projectTypes;
    }
}
?>