<?php 
include_once './config/params.php';
include_once './service/projectTypeRoom.php';
include_once './service/project.php';
include_once './service/userProperty.php';
include_once './config/config.php';
class Common{

	public static function getProjectList(){
		$projectType 		= new ProjectTypeRoom();
		$projectList 		= $projectType->getProjectTypeRoom();
		$projectList 		= $projectList['success'] ? $projectList['message'] : false;
		return $projectList;
	}

	public static function getProjectTypeById($projectTypeId){
		$projectType 		= new ProjectTypeRoom();
		$projectTypeDetail 	= $projectType->getProjectTypeById($projectTypeId);
		$projectTypeDetail	= $projectTypeDetail['success'] ? $projectTypeDetail['message'] : false;
		return $projectTypeDetail;
	}

	public static function getname($projname) {
        return str_replace("/", "_" , str_replace(" ", "" , str_replace("+", "" , str_replace("-", "_" ,strtolower($projname)))));
    }

    public static function postProjectObj($projectSelected){
    	$project 			= new Project();
    	return $project->postProject($projectSelected);
    }

    public static function getGoogleAddressByZipCode($url){
    	$con = new Config();
    	return $con->externalCurl($url,'get');
    }

    public static function updateUserProperty($userPropertyObj,$accessToken){
    	$userProperty 	= new UserProperty();
    	return $userProperty->updateUserProperty($userPropertyObj,$accessToken);
    }

    public static function updateProject($projectObj,$accessToken){
    	$project 	= new Project();
    	return $project->updateProject($projectObj,$accessToken);
    }

    public static function displaynum($cost = 0) {
        $value = (double)$cost;
        return '$'.number_format($value, 0,'', ',');
    }
}
?>