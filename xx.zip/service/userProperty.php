<?php
include_once './config/config.php';
class UserProperty {
  
    private $url;
  
    // get the database connection
    public function updateUserProperty($userPropertyObj,$accessToken){

        $this->url  = "user-properties";
        $con        = new Config();
        $response   = $con->kukunHTTPRequest($this->url,'POST',$userPropertyObj,$accessToken);
        return $response;
    }
}
?>