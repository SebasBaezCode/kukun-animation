<?php 
include_once 'service/common.php';
$userPropertyObj = $_POST['obj'];
$userProperty  	 = Common::updateUserProperty($userPropertyObj['userProperty'],$userPropertyObj['accessToken']);
echo json_encode($userProperty);

?>