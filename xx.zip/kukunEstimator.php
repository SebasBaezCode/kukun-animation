<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/css/main.min.css">
    <title>Document</title>
</head>
<body>

    <div class="k-container-full bg-estimator" role="main">
        <div class="container-company-logo">
            <img src="./assets/img/icons/company_logo.svg" class="company-logo" alt="Company logo"> 
        </div>
        <div class="kukun-estimator">
            <?php include_once 'views/projectList.php'; ?>
            <?php  include_once 'views/selectedProjects.php'; ?>
            <?php  include_once 'views/estimateOptions.php'; ?>
            <?php  include_once 'views/zipCode.php'; ?>
            <?php  include_once 'views/homeAddress.php'; ?>
            <?php  include_once 'views/homeData.php'; ?>
            <?php  include_once 'views/subTotal.php'; ?>
            <?php  include_once 'views/resultPage.php'; ?>
            <?php  include_once 'views/editProjects.php'; ?>
            <div class="container-poweredby">
                <a href="#" target="_blank">
                    <img src="./assets/img/icons/poweredBy.svg" class="powered-by" alt="Powered By Kukun"> 
                </a>
            </div>
        </div>
    </div>

    <script src="./assets/js/jquery-3.5.1.min.js"></script>
    <script src="./assets/js/materialize.min.js"></script>
    <script src="./assets/js/select2.min.js"></script>
    <script>
        $('.k-select').select2({
            minimumResultsForSearch: -1,
            width: '100%'
        });
        $(document).ready(function(){
            $('.collapsible').collapsible();
        });
    </script>
</body>
</html>

